import React, { useState, useCallback } from 'react';
import { Header } from './components/Header';
import { ImageInput } from './components/ImageInput';
import { TextInput } from './components/TextInput';
import { Button } from './components/Button';
import { GeneratedImage } from './components/GeneratedImage';
import { ImageEditor } from './components/ImageEditor';
import { EditPanel } from './components/EditPanel';
import { generateThumbnail, editThumbnail } from './services/geminiService';
import { FileInfo } from './types';
import { StyleSelector } from './components/StyleSelector';
import { ExpressionSelector } from './components/ExpressionSelector';
import { TextStyleSelector } from './components/TextStyleSelector';

function App() {
  const [fileInfo, setFileInfo] = useState<FileInfo | null>(null);
  const [selectedStyle, setSelectedStyle] = useState<string>('Cinematic');
  const [selectedExpression, setSelectedExpression] = useState<string>('Default');
  const [characterAction, setCharacterAction] = useState<string>('');
  const [backgroundDescription, setBackgroundDescription] = useState<string>('');
  const [thumbnailText, setThumbnailText] = useState<string>('');
  const [selectedTextStyle, setSelectedTextStyle] = useState<string>('Bold & Modern');
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  // New state for editing
  const [editMode, setEditMode] = useState(false);
  const [originalImage, setOriginalImage] = useState<string | null>(null);
  const [editPrompt, setEditPrompt] = useState('');
  const [brushSize, setBrushSize] = useState(40);
  const [maskImage, setMaskImage] = useState<string | null>(null);

  const handleImageChange = (newFileInfo: FileInfo | null) => {
    setFileInfo(newFileInfo);
    setGeneratedImage(null);
    setEditMode(false);
  };

  const handleGenerateClick = useCallback(async () => {
    if (!fileInfo || !selectedStyle || !thumbnailText) {
      setError('Please provide an image, select a style, and add thumbnail text.');
      return;
    }
    setEditMode(false);
    setIsLoading(true);
    setError(null);
    setGeneratedImage(null);

    try {
      const imageUrl = await generateThumbnail(
        fileInfo.base64,
        fileInfo.mimeType,
        {
          style: selectedStyle,
          expression: selectedExpression,
          text: thumbnailText,
          characterAction: characterAction,
          background: backgroundDescription,
          textStyle: selectedTextStyle,
        }
      );
      setGeneratedImage(imageUrl);
    } catch (err) {
      console.error(err);
      setError(err instanceof Error ? err.message : 'An unknown error occurred.');
    } finally {
      setIsLoading(false);
    }
  }, [fileInfo, selectedStyle, selectedExpression, thumbnailText, characterAction, backgroundDescription, selectedTextStyle]);

  const handleEnterEditMode = () => {
    if (!generatedImage) return;
    setOriginalImage(generatedImage);
    setEditMode(true);
    setError(null);
  };

  const handleCancelEdit = () => {
    setEditMode(false);
    setEditPrompt('');
    setMaskImage(null);
    setGeneratedImage(originalImage);
  };

  const handleApplyEdit = useCallback(async () => {
    if (!originalImage || !maskImage || !editPrompt) {
      setError('Please draw a mask and provide edit instructions.');
      return;
    }
    setIsLoading(true);
    setError(null);
    
    try {
      const newImageUrl = await editThumbnail(originalImage, maskImage, editPrompt);
      setGeneratedImage(newImageUrl);
      setEditMode(false);
      setEditPrompt('');
      setMaskImage(null);
    } catch (err) {
      console.error(err);
      setError(err instanceof Error ? err.message : 'An unknown error occurred.');
    } finally {
      setIsLoading(false);
    }
  }, [originalImage, maskImage, editPrompt]);


  const canGenerate = !!fileInfo && selectedStyle.trim() !== '' && thumbnailText.trim() !== '' && !isLoading;
  const canApplyEdit = !!maskImage && editPrompt.trim() !== '' && !isLoading;

  return (
    <div className="min-h-screen bg-slate-900 text-white font-sans flex flex-col items-center p-4 sm:p-6 lg:p-8">
      <Header />
      <main className="w-full max-w-7xl flex-grow grid grid-cols-1 lg:grid-cols-2 gap-8 mt-8">
        {/* Control Panel */}
        <div className="bg-slate-800/50 backdrop-blur-sm rounded-2xl p-6 lg:p-8 border border-slate-700 flex flex-col space-y-6 h-fit">
          {!editMode ? (
            <>
              <h2 className="text-2xl font-bold text-cyan-400">1. Customize Your Thumbnail</h2>
              <ImageInput onImageChange={handleImageChange} />
              <StyleSelector 
                selectedStyle={selectedStyle}
                onStyleSelect={setSelectedStyle}
              />
              <ExpressionSelector
                selectedExpression={selectedExpression}
                onExpressionSelect={setSelectedExpression}
              />
              <TextInput
                label="Character's Action (Optional)"
                placeholder="e.g., Holding a coffee mug"
                value={characterAction}
                onChange={(e) => setCharacterAction(e.target.value)}
              />
               <TextInput
                label="Background Description (Optional)"
                placeholder="e.g., A cozy cafe with warm lighting"
                value={backgroundDescription}
                onChange={(e) => setBackgroundDescription(e.target.value)}
              />
              <TextInput
                label="Text for the thumbnail"
                placeholder="e.g., MY EPIC VLOG!"
                value={thumbnailText}
                onChange={(e) => setThumbnailText(e.target.value)}
              />
              <TextStyleSelector
                selectedStyle={selectedTextStyle}
                onStyleSelect={setSelectedTextStyle}
              />
              <Button onClick={handleGenerateClick} disabled={!canGenerate} isLoading={isLoading}>
                {isLoading ? 'Generating...' : 'Generate Thumbnail'}
              </Button>
            </>
          ) : (
            <EditPanel 
              prompt={editPrompt}
              onPromptChange={setEditPrompt}
              brushSize={brushSize}
              onBrushSizeChange={setBrushSize}
              onApply={handleApplyEdit}
              onCancel={handleCancelEdit}
              isLoading={isLoading}
              disabled={!canApplyEdit}
            />
          )}

          {error && <p className="text-red-400 text-sm text-center mt-2">{error}</p>}
        </div>

        {/* Output Panel */}
        <div className="bg-slate-800/50 backdrop-blur-sm rounded-2xl p-6 lg:p-8 border border-slate-700 flex flex-col">
           <h2 className="text-2xl font-bold text-cyan-400 mb-6">{editMode ? '3. Paint the Area to Edit' : '2. Your AI-Generated Image'}</h2>
          
          {editMode ? (
            <ImageEditor 
              src={originalImage}
              brushSize={brushSize}
              onMaskUpdate={setMaskImage}
            />
          ) : (
            <GeneratedImage
              src={generatedImage}
              isLoading={isLoading}
              onEditClick={handleEnterEditMode}
            />
          )}
        </div>
      </main>
    </div>
  );
}

export default App;