
export interface FileInfo {
  name: string;
  mimeType: string;
  base64: string;
}
