import React from 'react';

const textStyles = [
  'Bold & Modern',
  'Elegant Script',
  'Gamer Style',
  'Handwritten',
  'Retro Wave',
  'Comic Book',
];

interface TextStyleSelectorProps {
  selectedStyle: string;
  onStyleSelect: (style: string) => void;
}

export const TextStyleSelector: React.FC<TextStyleSelectorProps> = ({ selectedStyle, onStyleSelect }) => {
  return (
    <div>
      <label className="block text-sm font-medium text-slate-300 mb-2">Choose a Text Style</label>
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
        {textStyles.map((style) => (
          <button
            key={style}
            onClick={() => onStyleSelect(style)}
            className={`w-full text-center px-4 py-3 rounded-lg border transition-all duration-200 text-sm font-semibold
              ${selectedStyle === style
                ? 'bg-purple-500 border-purple-400 text-white shadow-lg'
                : 'bg-slate-700/50 border-slate-600 hover:bg-slate-700 hover:border-slate-500'
              }`}
          >
            {style}
          </button>
        ))}
      </div>
    </div>
  );
};