
import React from 'react';

interface TextInputProps extends React.InputHTMLAttributes<HTMLInputElement | HTMLTextAreaElement> {
  label: string;
  as?: 'input' | 'textarea';
}

export const TextInput: React.FC<TextInputProps> = ({ label, as = 'input', ...props }) => {
  const commonClasses = "w-full px-4 py-3 bg-slate-700/50 border border-slate-600 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 outline-none transition-all duration-200 placeholder-slate-500";
  const InputComponent = as === 'textarea' ? 'textarea' : 'input';

  return (
    <div className="w-full">
      <label className="block text-sm font-medium text-slate-300 mb-2">{label}</label>
      <InputComponent
        className={`${commonClasses} ${as === 'textarea' ? 'min-h-[100px] resize-y' : ''}`}
        {...props}
      />
    </div>
  );
};
