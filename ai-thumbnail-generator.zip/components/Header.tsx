
import React from 'react';

export const Header: React.FC = () => {
  return (
    <header className="text-center w-full max-w-4xl">
      <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-500">
        AI Thumbnail Generator
      </h1>
      <p className="mt-4 text-lg text-slate-300">
        Powered by Gemini Nano Banana. Turn your photos into captivating thumbnails in seconds.
      </p>
    </header>
  );
};
