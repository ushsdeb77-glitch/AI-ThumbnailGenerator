import React from 'react';

const expressions = [
  'Default',
  'Happy',
  'Surprised',
  'Serious',
  'Angry',
  'Excited',
];

interface ExpressionSelectorProps {
  selectedExpression: string;
  onExpressionSelect: (expression: string) => void;
}

export const ExpressionSelector: React.FC<ExpressionSelectorProps> = ({ selectedExpression, onExpressionSelect }) => {
  return (
    <div>
      <label className="block text-sm font-medium text-slate-300 mb-2">Choose a Face Expression</label>
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
        {expressions.map((expression) => (
          <button
            key={expression}
            onClick={() => onExpressionSelect(expression)}
            className={`w-full text-center px-4 py-3 rounded-lg border transition-all duration-200 text-sm font-semibold
              ${selectedExpression === expression
                ? 'bg-cyan-500 border-cyan-400 text-white shadow-lg'
                : 'bg-slate-700/50 border-slate-600 hover:bg-slate-700 hover:border-slate-500'
              }`}
          >
            {expression}
          </button>
        ))}
      </div>
    </div>
  );
};
