
import React, { useState, useRef, useCallback } from 'react';
import { FileInfo } from '../types';
import { UploadIcon, XIcon } from './Icons';

interface ImageInputProps {
  onImageChange: (fileInfo: FileInfo | null) => void;
}

const fileToBase64 = (file: File): Promise<string> =>
  new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
        const result = reader.result as string;
        // remove data:mime/type;base64, part
        resolve(result.split(',')[1]);
    };
    reader.onerror = (error) => reject(error);
  });


export const ImageInput: React.FC<ImageInputProps> = ({ onImageChange }) => {
  const [preview, setPreview] = useState<string | null>(null);
  const [fileName, setFileName] = useState<string>('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = useCallback(async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      try {
        const base64 = await fileToBase64(file);
        const fileInfo: FileInfo = {
          name: file.name,
          mimeType: file.type,
          base64: base64,
        };
        setPreview(URL.createObjectURL(file));
        setFileName(file.name);
        onImageChange(fileInfo);
      } catch (error) {
        console.error("Error converting file to base64", error);
        onImageChange(null);
      }
    }
  }, [onImageChange]);

  const handleRemoveImage = useCallback(() => {
    setPreview(null);
    setFileName('');
    onImageChange(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  }, [onImageChange]);

  const handleSelectClick = () => {
    fileInputRef.current?.click();
  };

  return (
    <div className="space-y-4">
        <label className="block text-sm font-medium text-slate-300">Upload your photo/selfie</label>
        {preview ? (
        <div className="relative group w-full aspect-video rounded-lg overflow-hidden border-2 border-dashed border-slate-600">
          <img src={preview} alt="Image preview" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
            <button
              onClick={handleRemoveImage}
              className="p-2 rounded-full bg-red-500 hover:bg-red-600 text-white transition-colors"
              aria-label="Remove image"
            >
              <XIcon className="w-6 h-6" />
            </button>
          </div>
        </div>
        ) : (
        <div 
          onClick={handleSelectClick}
          className="flex justify-center items-center flex-col w-full aspect-video px-6 py-10 border-2 border-slate-600 border-dashed rounded-lg cursor-pointer hover:bg-slate-700/50 transition-colors"
        >
            <div className="text-center">
                <UploadIcon className="mx-auto h-12 w-12 text-slate-400" />
                <p className="mt-2 text-sm text-slate-400">
                    <span className="font-semibold text-cyan-400">Click to upload</span> or drag and drop
                </p>
                <p className="text-xs text-slate-500">PNG, JPG, WEBP up to 10MB</p>
            </div>
            <input
                ref={fileInputRef}
                type="file"
                className="hidden"
                accept="image/*"
                onChange={handleFileChange}
            />
        </div>
        )}
    </div>
  );
};
