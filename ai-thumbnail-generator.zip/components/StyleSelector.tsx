import React from 'react';

const styles = [
  'Cinematic',
  'Vintage',
  'Neon Punk',
  'Minimalist',
  'Cartoonish',
  'Fantasy Art',
];

interface StyleSelectorProps {
  selectedStyle: string;
  onStyleSelect: (style: string) => void;
}

export const StyleSelector: React.FC<StyleSelectorProps> = ({ selectedStyle, onStyleSelect }) => {
  return (
    <div>
      <label className="block text-sm font-medium text-slate-300 mb-2">Describe Your Style</label>
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
        {styles.map((style) => (
          <button
            key={style}
            onClick={() => onStyleSelect(style)}
            className={`w-full text-center px-4 py-3 rounded-lg border transition-all duration-200 text-sm font-semibold
              ${selectedStyle === style
                ? 'bg-cyan-500 border-cyan-400 text-white shadow-lg'
                : 'bg-slate-700/50 border-slate-600 hover:bg-slate-700 hover:border-slate-500'
              }`}
          >
            {style}
          </button>
        ))}
      </div>
    </div>
  );
};
