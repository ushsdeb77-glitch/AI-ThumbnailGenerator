import React from 'react';
import { Spinner } from './Spinner';
import { DownloadIcon, ImageIcon, PencilIcon } from './Icons';

interface GeneratedImageProps {
  src: string | null;
  isLoading: boolean;
  onEditClick: () => void;
}

export const GeneratedImage: React.FC<GeneratedImageProps> = ({ src, isLoading, onEditClick }) => {
  const Placeholder = () => (
    <div className="flex flex-col items-center justify-center h-full text-center text-slate-500">
      <ImageIcon className="w-16 h-16 mb-4" />
      <h3 className="text-lg font-semibold text-slate-400">Your thumbnail will appear here</h3>
      <p className="text-sm">Fill out the details and click "Generate" to start.</p>
    </div>
  );

  return (
    <div className="w-full aspect-video bg-slate-900/50 rounded-lg flex items-center justify-center relative overflow-hidden border border-slate-700 group">
      {isLoading ? (
          <div className="flex flex-col items-center justify-center">
            <Spinner />
            <p className="mt-4 text-slate-300">AI is creating magic...</p>
          </div>
      ) : src ? (
        <>
          <img src={src} alt="Generated thumbnail" className="w-full h-full object-contain" />
          <div className="absolute bottom-4 right-4 flex items-center space-x-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
            <button
              onClick={onEditClick}
              className="bg-purple-500 text-white p-3 rounded-full shadow-lg hover:bg-purple-600 transition-transform hover:scale-110"
              aria-label="Edit image"
            >
              <PencilIcon className="w-6 h-6" />
            </button>
            <a
              href={src}
              download="ai-thumbnail.png"
              className="bg-cyan-500 text-white p-3 rounded-full shadow-lg hover:bg-cyan-600 transition-transform hover:scale-110"
              aria-label="Download image"
            >
              <DownloadIcon className="w-6 h-6" />
            </a>
          </div>
        </>
      ) : (
        <Placeholder />
      )}
    </div>
  );
};