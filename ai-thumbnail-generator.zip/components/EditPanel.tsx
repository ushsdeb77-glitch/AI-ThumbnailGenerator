import React from 'react';
import { TextInput } from './TextInput';
import { Button } from './Button';

interface EditPanelProps {
  prompt: string;
  onPromptChange: (value: string) => void;
  brushSize: number;
  onBrushSizeChange: (value: number) => void;
  onApply: () => void;
  onCancel: () => void;
  isLoading: boolean;
  disabled: boolean;
}

export const EditPanel: React.FC<EditPanelProps> = ({
  prompt,
  onPromptChange,
  brushSize,
  onBrushSizeChange,
  onApply,
  onCancel,
  isLoading,
  disabled
}) => {
  return (
    <>
      <h2 className="text-2xl font-bold text-purple-400">2. Edit Your Thumbnail</h2>
      
      <TextInput
        label="Edit Instructions"
        placeholder="e.g., Add a futuristic helmet"
        value={prompt}
        onChange={(e) => onPromptChange(e.target.value)}
        as="textarea"
      />

      <div>
        <label htmlFor="brush-size" className="block text-sm font-medium text-slate-300 mb-2">
          Brush Size: {brushSize}px
        </label>
        <input
          id="brush-size"
          type="range"
          min="5"
          max="100"
          value={brushSize}
          onChange={(e) => onBrushSizeChange(Number(e.target.value))}
          className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-purple-500"
        />
      </div>

      <div className="flex flex-col sm:flex-row gap-4">
        <button
          onClick={onCancel}
          className="w-full px-6 py-4 text-lg font-bold text-slate-300 bg-slate-700 rounded-lg hover:bg-slate-600 focus:outline-none focus:ring-4 focus:ring-slate-500/50 transition-all duration-300 ease-in-out"
        >
          Cancel
        </button>
        <Button onClick={onApply} disabled={disabled} isLoading={isLoading}>
          {isLoading ? 'Applying Edit...' : 'Apply Edit'}
        </Button>
      </div>
    </>
  );
};