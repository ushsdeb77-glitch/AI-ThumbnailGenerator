import { GoogleGenAI, Modality } from "@google/genai";

const MODEL_NAME = 'gemini-2.5-flash-image';

const getBase64 = (dataUrl: string) => dataUrl.split(',')[1];
const getMimeType = (dataUrl: string) => dataUrl.substring(dataUrl.indexOf(":") + 1, dataUrl.indexOf(";"));

const handleApiResponse = (response: any): string => {
  const firstPart = response.candidates?.[0]?.content?.parts?.[0];

  if (firstPart && firstPart.inlineData) {
    const base64ImageBytes: string = firstPart.inlineData.data;
    const imageMimeType: string = firstPart.inlineData.mimeType;
    return `data:${imageMimeType};base64,${base64ImageBytes}`;
  } else {
    throw new Error("No image was generated. The response may contain safety blocks or be empty.");
  }
};

interface ThumbnailOptions {
  style: string;
  expression: string;
  text: string;
  characterAction: string;
  background: string;
  textStyle: string;
}

export const generateThumbnail = async (
  imageBase64: string,
  mimeType: string,
  options: ThumbnailOptions
): Promise<string> => {
  if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable is not set.");
  }

  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  const { style, expression, text, characterAction, background, textStyle } = options;

  const promptParts = [
    `Based on the provided image, generate a visually appealing thumbnail.`,
    `Follow these instructions precisely:`,
    `1. **Overall Style and Mood**: ${style}.`
  ];

  if (expression && expression !== 'Default') {
    promptParts.push(`2. **Main Subject's Expression**: The main subject should have a ${expression.toLowerCase()} facial expression.`);
  }

  if (characterAction) {
    promptParts.push(`3. **Main Subject's Action**: The character should be depicted as: "${characterAction}".`);
  }
  
  if (background) {
    promptParts.push(`4. **Background Details**: The background should be transformed to look like: "${background}".`);
  }

  promptParts.push(`5. **Text to Add**: Add the text "${text}".`);
  promptParts.push(`6. **Text Style**: The text style must be "${textStyle}". The text must be prominent, clear, readable, and creatively integrated into the thumbnail's design.`);
  promptParts.push(`7. **Composition**: The subject from the original image should be the main focus. Enhance the subject and background according to all the specified details, ensuring a cohesive and professional look.`);
  
  const fullPrompt = promptParts.join('\n');

  try {
    const response = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: {
        parts: [
          {
            inlineData: {
              data: imageBase64,
              mimeType: mimeType,
            },
          },
          {
            text: fullPrompt,
          },
        ],
      },
      config: {
        responseModalities: [Modality.IMAGE],
      },
    });

    return handleApiResponse(response);
  } catch (error) {
    console.error("Error generating thumbnail with Gemini API:", error);
    throw new Error("Failed to generate thumbnail. Please try again.");
  }
};

export const editThumbnail = async (
  originalImage: string, // dataURL
  maskImage: string,     // dataURL
  prompt: string
): Promise<string> => {
  if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable is not set.");
  }

  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const fullPrompt = `
    Perform an in-painting task.
    You are given three inputs: an original image, a mask image, and a text prompt.
    The mask image indicates the area to edit: the white area is the region to change, and the black area is the region to keep.
    Modify the original image ONLY in the areas designated by the white parts of the mask, based on this instruction: "${prompt}".
    The output should be the complete, edited image, with the changes seamlessly blended.
  `;

  try {
    const response = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: {
        parts: [
          { text: fullPrompt },
          {
            inlineData: {
              data: getBase64(originalImage),
              mimeType: getMimeType(originalImage),
            },
          },
          {
            inlineData: {
              data: getBase64(maskImage),
              mimeType: 'image/png',
            },
          },
        ],
      },
      config: {
        responseModalities: [Modality.IMAGE],
      },
    });
    
    return handleApiResponse(response);
  } catch (error) {
    console.error("Error editing thumbnail with Gemini API:", error);
    throw new Error("Failed to edit thumbnail. Please try again.");
  }
};